Recreation of ps0 ufo project using pygame with abstraction layer.
