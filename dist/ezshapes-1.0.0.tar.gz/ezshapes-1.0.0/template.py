from ezshapes.renderer import *

setup(500, 500)


while True:

  # Add code here
  set_background("grey50")
  # 
  rect(50, 50, 50, 50, "grey", 5, "blanchedalmond")
  rect(110, 50, 50, 50, "grey")
  update_screen()
