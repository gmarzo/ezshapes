from src.package_name.functions import *

setup(500, 500)


while True:

  # Add code here
  set_background("blue")
  # 
  update_screen()
